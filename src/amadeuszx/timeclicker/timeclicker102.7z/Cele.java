package amadeuszx.timeclicker;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;

public class Cele
{
	private Color wzorTime =  new Color(50, 111, 201);
	private int[] wzorSzTime = new int[10];
	
	private Color wzorZolty =  new Color(254, 255, 0);
	private int[] wzorSzZolty = new int[10];
	private int[] wzorSzDZolty = new int[10]; 					//z czerwon� ramk�
	private Color wzorBialy = new Color(255, 255, 255);
	private int[] wzorSzBialy = new int[10];
	private int[] wzorSzCzBialy = new int[10];
	private int[] wzorSzDBialy = new int[10];					//z czerwon� ramk�
	private Color wzorCzerwony = new Color(255, 0, 0);
	private int[] wzorSzCzerwony = new int[10];

	
	private Color[] wzorTecza1 = {new Color(0, 254, 247), new Color(0, 254, 247), new Color(0, 254, 246), new Color(0, 254, 247)};
	private int[] wzorSzTecza1 = new int[wzorTecza1.length];
	private Color[] wzorTecza2 = {new Color(255, 126, 0), new Color(255, 121, 0), new Color(255, 115, 0), new Color(255, 109, 0)};
	private int[] wzorSzTecza2 = new int[wzorTecza1.length];
	private Color[] wzorTecza3 = {new Color(12, 255, 0), new Color(12, 255, 0), new Color(12, 255, 0), new Color(12, 255, 0)};
	private int[] wzorSzTecza3 = new int[wzorTecza1.length];
	
	private Grafika gg;
	boolean stop = false;
	int[][] result;
	
	private int xp, yp;

	// x 600 - 1200 y 400 - 600
	public Cele(Grafika ggt)
	{
		gg = ggt;
		for (int i = 0; i < 10; i++)
		{
			wzorSzTime[i] = wzorTime.getRGB();
			wzorSzZolty[i] = wzorZolty.getRGB();
			wzorSzDZolty[i] = wzorZolty.getRGB();
			wzorSzBialy[i] = wzorBialy.getRGB();
			wzorSzCzBialy[i] = wzorBialy.getRGB();
			wzorSzDBialy[i] = wzorBialy.getRGB();
			wzorSzCzerwony[i] = wzorCzerwony.getRGB();
		}
		
		for (int i = 0; i < wzorTecza1.length; i++)
		{
			wzorSzTecza1[i] = wzorTecza1[i].getRGB();
			wzorSzTecza2[i] = wzorTecza2[i].getRGB();
			wzorSzTecza3[i] = wzorTecza3[i].getRGB();
		}
		
		wzorSzDZolty[0] = new Color(255, 0, 0).getRGB(); //czerwona ramka klocka ��tego 
		wzorSzCzBialy[0] = new Color(0, 0, 0).getRGB(); //czarna ramka klocka bia�ego
		wzorSzDBialy[0] = new Color(255, 0, 0).getRGB(); //czerwona ramka klocka bia�ego
	}

	void szukajCelu()
	{
		new Thread()
		{
			@Override
			public void run()
			{
			
				while (!stop)
				{
					//pobieranie obrazka do przeszukania
					BufferedImage bi = gg.robot.createScreenCapture(obszarSzukania());
				
					int width = bi.getWidth();
					int height = bi.getHeight();
					result = new int[height][width];
					//przetworzenie obrazka na int - �eby szybko szuka�
					for (int row = 0; row < height; row++)
						for (int col = 0; col < width; col++)
							result[row][col] = bi.getRGB(col, row);
					
					//hierarchia ostrza�u klock�w
					testujTecza(wzorSzTecza1);
					testujTecza(wzorSzTecza2);
					testujTecza(wzorSzTecza3);
					try
					{
						if(namierzanie(wzorSzDZolty))
							Thread.sleep(400);
						else if(namierzanie(wzorSzDBialy))
							Thread.sleep(200);
							else if(namierzanie(wzorSzZolty))
									Thread.sleep(800);
								else if(namierzanie(wzorSzCzBialy))
									Thread.sleep(400);
									else if(namierzanie(wzorSzTime))
											Thread.sleep(1600);
										else if(namierzanie(wzorSzCzerwony))
											Thread.sleep(200);
											else if(namierzanie(wzorSzBialy))
												Thread.sleep(400);
					}
					catch (InterruptedException e)
					{
							e.printStackTrace();
					}
						
				}// while loop
			
			}

		}.start();

	}
	
	void testujTecza(final int[] koloryTeczy){
		new Thread(){
			@Override
			public void run()
			{
				if(namierzanie(koloryTeczy))
					{
					gg.robot.mousePress(InputEvent.BUTTON1_MASK);
					gg.robot.mouseRelease(InputEvent.BUTTON1_MASK);
					System.out.println("TECZA - trafiona?");
					};
			}
		}.start();
	}
	
	private boolean namierzanie(int[] wzor){
		boolean kolorek = false;
		int[][] tab = result;
		
		DOROBOTY:
			for (int row = 0; row < tab.length; row++)
				for (int col = 0; col < tab[row].length; col++)
					if (tab[row][col] == wzor[0]) //je�li na szukanym obrazku znale�li�my punkt w szukanym kolorze 
						for (int xx = col + 1; xx < col + wzor.length; xx++)  //szukamy kolejnych 9 punkt�w
						{
							if (xx<(gg.getXk()-gg.getXp()) && tab[row][xx] == wzor[xx - col]) //sprawdzamy kolejne pkt.
							{
								if (xx == col + wzor.length - 1) //je�li doszli�my do ostatniego pkt.
								{
									if(stop)break DOROBOTY; // wy��czenie automatycznego strzelania
									
									gg.robot.mouseMove(xp + col, yp + row);
									kolorek = true;
									break DOROBOTY;
								}
							}
							else
								break;
						}

		return kolorek;
	}

	private Rectangle obszarSzukania(){
		xp = gg.getXp();
		int xwym = gg.getXk()-xp;
		yp = gg.getYp();
		int ywym = gg.getYk()-yp;
		
		return new Rectangle(xp, yp, xwym, ywym);
	}
}